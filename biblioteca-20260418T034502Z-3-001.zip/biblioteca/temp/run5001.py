import sys
sys.path.insert(0, r'c:\Users\user\biblioteca')
from biblioteca_python.app import app
app.run(debug=False, port=5001, host='0.0.0.0', use_reloader=False)
